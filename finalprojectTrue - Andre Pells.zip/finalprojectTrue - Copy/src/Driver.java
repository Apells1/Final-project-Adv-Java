/**
 * This program simulates a automated parking ticket machine
 * @author  Andre Pells
 * @version 1.0
 * @since   5-29-2020
 */
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;
import java.util.Random;
public class Driver {
    public static void main(String[] args) throws IOException {
        input finalOne = new input();
        input.ticketFactory1 ticketTest = input.ticketFactory1.getInstance();
        // here i create the singleton factory
        Scanner keyboard = new Scanner(System.in);
        int userChoiceTrue = 0;
        int userChoice = 0;
        int userChoice2 = 0;
int factoryVariable = 0;
        int randomTime;

        //thanks for teaching an amazing and educating class, is was great too have you Mr green, and i will see you in advanced javascript!


      //So my impression is that only one ticket type is allowed per checkin, either a lost ticket, normal ticket or special ticket, and this program succeeds at printing the receipt based on which kind of ticket the user has printed. if the user chooses more then one it will pick the last one clicked
        LocalDate today = LocalDate.now();
        LocalTime checkIn = null;
        LocalTime checkOut = null;


        do {
//here i create a do-while loop asking the user what their action will be.
            System.out.println(" ");
            System.out.print("Best Value Parking Garage \n");
            System.out.print("--------------------- \n");
            System.out.print("1 " + "Check in\n");
            System.out.print("2 " + "Special Event\n");
            System.out.print("3 " + "Close Garage\n");
            System.out.print("Please select your action.\n");

            userChoice = keyboard.nextInt();

            if(userChoice == 1){
                Random random = new Random();
                int rand1 = random.nextInt(11) + 1;
                System.out.print("Check-in time created\n");
checkIn = LocalTime.of(rand1, 0, 0);
//if the check in is picked it assigns the user a check in time and "locks" the final receipt into a normal ticket
            }
            if(userChoice == 2){
                factoryVariable = 2;
System.out.println("Special ticket receipt created.");
             //if the user picks a special ticket it assigns the variable that decides what kind of ticket the factory will make into one for a special ticket.


            }

        } while (userChoice != 3);

        do { //here i will ask the user if they wish to check out or document a lost ticket.
            System.out.println(" ");
            System.out.print("Best Value Parking Garage \n");
            System.out.print("--------------------- \n");
            System.out.print("1 " + "Check Out\n");
            System.out.print("2 " + "Lost Ticket\n");
            System.out.print("Please select your action.\n");
            userChoiceTrue = keyboard.nextInt();

            if(userChoiceTrue == 1){
                if(checkIn != null){
                    //if the user checked in then this code will enact and create a normal ticket based on a random time
                    factoryVariable=1;
                    // here's where it locks it
                Random random = new Random();
                int rand2 = (random.nextInt(11) + 1) + 12;

              checkOut = LocalTime.of(rand2, 0, 0);

                    input.normalTicket normal = input.normalTicket.getInstance();
//here is the normal ticket being checked by the singleton method
              normal.ticketPriceNormal(checkIn, checkOut);
              normal.ticketPrice();
//i couldn't get the factory to work for this without making the code really yucky, as the factory couldn't access the normal tickets exclusive method, but giving all of the other tickets access to this method seemed worse.
              normal.displayTicket();



            }
                else if(factoryVariable == 2 || factoryVariable == 3) {
                    input.ticket ticket1 = ticketTest.getTicketType(factoryVariable);
                    ticket1.ticketPrice();
                    ticket1.displayTicket();
                    //here i say if the user did not check in, but chose to make another kind of ticket to bring up the factory and make the receipt for whichever one they chose.
                    // the ticketprice function adds either to the grand total
                }

                input.outputwriter();
                input.inputReader();
                //while the file IO is a bit simplified it still shows adequate use of file input and output.

            }
            if(userChoiceTrue == 2){

                factoryVariable = 3;
System.out.println("Lost ticket receipt created.");
             //here if the user chooses a lost ticket it makes the factory variable switch to  one for a lost ticket
            }


        }
        while (userChoiceTrue != 1);

    }}