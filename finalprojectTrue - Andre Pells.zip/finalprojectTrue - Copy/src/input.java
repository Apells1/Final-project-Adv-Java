import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.io.*;
import java.util.Scanner;

public class input<checkOut> {
private static int grandTotal = 0;
private static int totalTickets = 0;
    interface ticket {
        public void ticketPrice();
        public void displayTicket();
        final int minFee = 5;
        final int maxFee = 15;
//here is the ticket interface with the minimum fee and maximum fee of a ticket as well as 2 methods, ticket price which will carry the price of each ticket, as well as a method that will display the receipt

    }

     static class specialTicket implements ticket{


        @Override
        public void ticketPrice() {
int Price = 20;
grandTotal += Price;
//i add the 20 dollars to the grand total
            totalTickets++;
            //i also add 1 to the total amount of tickets
        }
        //here i override the price and set it to 20 dollars

        @Override
        public void displayTicket() {

            System.out.println("Special event \n $20.00$");
            //i also override the display method to display an adequate receipt
        }



    }
     static class normalTicket implements ticket{
private static normalTicket onlyOne;



         //for this add a new date method and do aritmatic on it
        private Duration tester;
        private LocalTime in;
        private LocalTime out;
        private double truePrice;
        private double hoursBetween;
//here i create the variables to measure the duration between the check in and checkout
private static normalTicket normal1 = null;
         private normalTicket(){}
         public static normalTicket getInstance(){
             if(normal1 == null) {
                 normal1 = new normalTicket();
             }
             return normal1;
         }

        public void ticketPriceNormal(LocalTime inTime, LocalTime outTime) {
            in = inTime;
            out = outTime;
            Duration timeBetween = Duration.between(in, out);
            hoursBetween = (double)(timeBetween.getSeconds() / 60) /60;
//here i calculate the amount of hours the user has been parked
            if (hoursBetween <= 3) {
                truePrice +=minFee;
            }

            if (hoursBetween > 3 && hoursBetween < 24) {
                truePrice += Math.round((hoursBetween + minFee)*100.0)/100.0;

            }
            if (hoursBetween >= 24) {
                truePrice += minFee + maxFee;
            }
//here i assign the price on the amount of hours
        }

         @Override
         public void ticketPrice() {
             grandTotal+=truePrice;
             //i add the price to the grand total
             totalTickets++;
             //i also add 1 to the total amount of tickets
         }

         @Override
        public void displayTicket() {
            System.out.println(hoursBetween+" hours parked between "+in+""+"-"+out+" \n $"+truePrice);
        }
        // and finally i display the receipt

    }






    static class lostTicket implements ticket{

        @Override
        public void ticketPrice() {
            int price = 25;
            //here i set the price of a lost ticket
            grandTotal += price;
            totalTickets++;
            //i also add 1 to the total amount of tickets
        }

        @Override
        public void displayTicket() {
            System.out.println("Lost ticket \n $25.00$");
            //and again i print out the receipt
        }
    }



    public static void grandTotal(){
        System.out.println("Your grand total comes to: "+grandTotal);
    }

    public static void outputwriter() throws IOException {
        FileWriter outputPrice = new FileWriter("price.txt", true);
        FileWriter outputTickets = new FileWriter("ticket.txt", true);
        outputPrice.write(String.valueOf(grandTotal)+"\n");

        outputTickets.write(String.valueOf(totalTickets)+"\n");
        outputTickets.close();
        outputPrice.close();
    }
    public static void inputReader() throws IOException {
        int absTotalPrice = 0;
        int absTickets = 0;
        File ticketsFile =new File("ticket.txt");
        File priceFile =new File("price.txt");
        Scanner inputTicket= new Scanner(ticketsFile);
        Scanner inputPrice= new Scanner(priceFile);



      while(inputPrice.hasNext()){
            absTotalPrice += Integer.parseInt(inputPrice.nextLine());

        }
      inputPrice.close();
        while(inputTicket.hasNext()){
            absTickets += Integer.parseInt(inputTicket.nextLine());

        }
        inputTicket.close();
        System.out.println("Activity to date:");
        System.out.println("\n");

        System.out.println("$"+absTotalPrice+" collected from "+ absTickets+ " tickets");

        }







    public static class ticketFactory1 {

//here is my first factory where i find out what kind of ticket the user needs
private static ticketFactory1 factory1 = null;
        private ticketFactory1(){}
        public static ticketFactory1 getInstance(){
            if(factory1 == null) {
                factory1 = new ticketFactory1();
            }
            return factory1;
            // i went for the "lazy" version of a singleton
        }


        protected static ticket getTicketType(int userChoice){
//i protect the method. this is used to decide what ticket to make.
            //though i couldn't really find a clean way to make a normal ticket
ticket ticketTest = null;


            if(userChoice == 2){
                ticketTest = new specialTicket();
            }
            if(userChoice == 3){
                ticketTest = new lostTicket();
            }

            return ticketTest;
            //here is the code to decide which kind of ticket to make.
        }
    }


}